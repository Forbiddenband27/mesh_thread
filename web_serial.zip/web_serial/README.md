# RaspberryPi



## Adafruit_Python_DHT

来自 Adafruit 的 DHT 传感器驱动 Python 库。



## Adafruit_Python_SSD1306

来自 Adafruit 的 OELD 驱动 Python 库



## mjpg-stramer

树莓派远程摄像头



## piclone

clone 当前树莓派系统镜像，可用于恢复。



## rpi-clone

另一个 clone 当前树莓派系统镜像。



## timer

使用 0.96inch OLED 实现的时钟，带树莓派分配得到的 IP 显示。



## RaspberryPi-script

一些实用功能脚本



## web-serial

网页版串口助手。通过 Python + Django + pyserial 实现。



