sudo pip3 install --upgrade pip
pip3 install requests
pip3 install lxml
pip3 install pandas
pip3 install bs4
pip3 install matplotlib
pip3 install numpy
pip3 install pyparsing
pip3 install scipy
pip3 install dateutil

