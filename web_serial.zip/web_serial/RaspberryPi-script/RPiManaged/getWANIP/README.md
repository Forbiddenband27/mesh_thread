# Developer Documents

## packages depends on

requests; bs4；

### Install packages

```shell
$
$ sudo pip3 install requests
$ sudo pip3 install beautifulsoup4
$
```



## run getWANIP.py

```shell
$
$ wget https://raw.githubusercontent.com/RDpWTeHM/RaspberryPi/master/RaspberryPi-script/RPiManaged/getWANIP/getWANIP.py
$ chmod +x getWANIP.py
$ 
$ ## 运行脚本，获得到 WAN IP 并直接打印到标准输出
$ ./getWANIP.py 
get HTML text OK!
153.35.***.***
$
```





