from django.apps import AppConfig


class SerialcomConfig(AppConfig):
    name = 'serialcom'
